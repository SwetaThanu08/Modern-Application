import java.sql.*;
import java.util.Scanner;
public class ConnectionOne {

	public static void main(String[] args) {
	
		try 
		{
			// Register the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			// Connection
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/clg","root","Vidyaarvind08*");
			
			// Statement 
			PreparedStatement stmt = conn.prepareStatement("Insert into clgdata values(?,?,?,?,?)");
			Scanner sc = new Scanner(System.in);
			System.out.println("Please enter the S.no");
			int sno = sc.nextInt();
			stmt.setInt(1,sno);
			
			System.out.println("Please enter the dept name");
			String dept = sc.next();
			stmt.setString(2,dept);
			
			System.out.println("Please enter the dept HOD name");
			String depthod = sc.next();
			stmt.setString(3,depthod);
			
			System.out.println("Please enter the student name");
			String stu = sc.next();
			stmt.setString(4,stu);
			
			System.out.println("Please enter the campuse location");
			String campus = sc.next();
			stmt.setString(5,campus);
			
			// Execute the query 
			int result = stmt.executeUpdate();
			
			System.out.println("result --> " +result);
			
			
			// close connection f
			conn.close();
		}
		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
